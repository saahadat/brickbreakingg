/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package brickbreaking;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * @author Asus VivoBook
 */
public class Game2 extends JPanel implements KeyListener,ActionListener {

    private boolean play2=false;
    
    private Timer timer2;
    private int delay= 4;
    
    //private int speed = 5;
    
    private int playerX= 345;
    private int playerY= 134;
    
    private int ballposX= 340;
    private int ballposY = 245;
    
    private int ballXdir = -7;
    private int ballYdir = -7;
    
    private ImageIcon img; 
    
    Game2(){
        
        initComponents2();
        
        
    }
    
    public void initComponents2(){
        
        addKeyListener(this);
        setFocusable(true);
        
        timer2 = new Timer(delay,this);
        timer2.start();
        
        
        
    }
    
    /**
     *
     * @param g
     */
    @Override
    public void paint(Graphics g){
        
        //background
        
        g.setColor(Color.pink);
        g.fillRect(0, 0, 700, 600);
        
        //score
        /*
        g.setColor(Color.yellow);
        g.setFont(new Font("serif",Font.BOLD,27));
        g.drawString("Score", 590, 30);*/
        
        
        //the Paddle
        g.setColor(Color.blue);
        g.fillRect(playerX,playerY,40,40);
        
        
        //the ball
        g.setColor(Color.red);
        g.fillOval(ballposX,ballposY,20,20);
        
        //when lose
        
        if(playerX<1||playerX>670||playerY<1||playerY>570){
            play2= false;
            g.setColor(Color.red);
            g.setFont(new Font("serif",Font.BOLD,30));
            g.drawString("Better Luck Next Time", 160, 280);
            g.drawString("Press Enter to play again", 160, 320);
            
        }
        else if(new Rectangle(ballposX,ballposY,20,20).intersects(new Rectangle(playerX,playerY,40,40))){
            
            play2 = false;
            g.setColor(Color.red);
            g.setFont(new Font("MV boli",Font.BOLD,35));
            g.drawString("Game Over", 160, 280);
            g.drawString("Press Enter to play again", 160, 320);
        }
        
    }
    
    
    @Override
    public void keyTyped(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
   
      
    
    }

    @Override
    public void keyPressed(KeyEvent e) {
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
       
       if(e.getKeyCode()== KeyEvent.VK_RIGHT){
           
           if(!play2){
               
               play2= true;
               ballposX= 340;
               ballposY = 245;
               ballXdir = -7;
               ballYdir = -7;
               playerX = 345;
               playerY = 134;
           }
           
           moveRight();
           
       }
       if(e.getKeyCode()==KeyEvent.VK_LEFT){
           
           if(!play2){
               
               play2= true;
               ballposX= 340;
               ballposY = 245;
               ballXdir = -7;
               ballYdir = -7;
               playerX = 345;
               playerY = 134;
           }
           
           moveLeft();
           
       }
       if(e.getKeyCode()==KeyEvent.VK_UP){
           
           if(!play2){
               
               play2= true;
               ballposX= 340;
               ballposY = 245;
               ballXdir = -7;
               ballYdir = -7;
               playerX = 345;
               playerY = 134;
           }
           
           moveUp();
       }
       if(e.getKeyCode()== KeyEvent.VK_DOWN){
           
           if(!play2){
               
               play2= true;
               ballposX= 340;
               ballposY = 245;
               ballXdir = -7;
               ballYdir = -7;
               playerX = 345;
               playerY = 134;
           }
           
           moveDown();
           
       }
       if(e.getKeyCode()== KeyEvent.VK_ENTER){
           
           if(!play2){
               
               play2=true;
               ballposX= 340;
               ballposY = 245;
               ballXdir = -7;
               ballYdir = -7;
               playerX = 345;
               playerY = 134;
               
               
               repaint();
           }
           
       }
       
    }   
       
    @Override
    public void keyReleased(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
   
      public void moveRight(){
            
            
            playerX = playerX + 50;
            
        }
      public void moveLeft(){
          
             playerX= playerX - 50;
          
      }
      public void moveUp(){
          
          
          playerY = playerY -50;
          
      }
      
      public void moveDown(){
          
          
          playerY = playerY + 50;
          
      }
      
    
    @Override
    public void actionPerformed(ActionEvent e) {
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    
       ballposX = ballposX + ballXdir;
       ballposY = ballposY + ballYdir;
    
       //check collision with wall
    if(play2){
        
        if(ballposX<20){
           
           ballXdir = -ballXdir;
           
           
       }
       if(ballposX>680){
           
           ballXdir = -ballXdir;
           
       }
       if(ballposY<20){
           
           ballYdir = -ballYdir;
       }
       if(ballposY>580){
           
           ballYdir = -ballYdir;
       }
       
       repaint();
    }   
       
       
    }

    
    
}
