/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package brickbreaking;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Asus VivoBook
 */
public class BrickBreaking extends JFrame {

    /**
     * @param args the command line arguments
     */
    private Container c;
    private JLabel name,pic1;
    private Font f1,f2;
    private ImageIcon img;
    private Cursor cursor;
    JButton btn1,btn2,btn3;
    JPanel panel1;
    
    
    BrickBreaking(){
        
        initComponents();
        
    }
    
    
    public void initComponents(){
        
        c = this.getContentPane();
        c.setBackground(Color.green);
        c.setLayout(null);
        
        f1 = new Font("Ariel",Font.BOLD,26);
        //f1.setForeground(Color.red);
        f2= new Font("Ariel",Font.BOLD,20);
        
        cursor = new Cursor(Cursor.HAND_CURSOR);
        
        
        img = new ImageIcon(getClass().getResource("controller.png"));
        
        this.setIconImage(img.getImage());
        
        name = new JLabel();
        name.setText("Brickbreaking Game");
        name.setBounds(210,100,300,30);
        name.setFont(f1);
        name.setForeground(Color.red);
        //name.setOpaque(true);
        c.add(name);
        
        pic1= new JLabel(img);
        pic1.setBounds(200,110,img.getIconWidth(),img.getIconHeight());
        c.add(pic1);
        
        btn1= new JButton("START BrickBreaking");
        btn1.setBounds(210,380,250,30);
        btn1.setFocusable(false);
        btn1.setForeground(Color.CYAN);
        btn1.setBackground(Color.blue);
        btn1.setFont(f2);
        btn1.setCursor(cursor);
        c.add(btn1);
        
        btn1.addActionListener(new ActionListener(){
            
        @Override
        public void actionPerformed(ActionEvent e){
            
            JFrame g1frame = new JFrame();
            
            Game1 game1 = new Game1();
            
            g1frame.setVisible(true);
            g1frame.setBounds(30,30,700,600);
            g1frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            g1frame.setTitle("BrickBreaking Demo");
            g1frame.add(game1);
            
            
            ImageIcon img = new ImageIcon(getClass().getResource("controller.png"));
            g1frame.setIconImage(img.getImage());
            
        }    
            
            
            
        });
        
        
        btn2 = new JButton("Start fun");
        btn2.setBounds(250,430,180,30);
        btn2.setBackground(Color.blue);
        btn2.setForeground(Color.CYAN);
        btn2.setFocusable(false);
        btn2.setFont(f2);
        btn2.setCursor(cursor);
        c.add(btn2);
        
        btn2.addActionListener(new ActionListener(){
        
        @Override
        public void actionPerformed(ActionEvent e){
            
            
            
            JFrame Game2frame = new JFrame();
            
            Game2 game2 = new Game2();
            
            Game2frame.setVisible(true);
            Game2frame.setBounds(30,30,700,600);
            Game2frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            Game2frame.setTitle("Avoid The Ball Demo");
            Game2frame.add(game2);
            
            
            ImageIcon img = new ImageIcon(getClass().getResource("controller.png"));
            Game2frame.setIconImage(img.getImage());
            
            //BrickBreaking.startframe.setDisposed(true);
            
            
            
            
            
        }
        
        
        
        });
        
        
        btn3 = new JButton("info");
        btn3.setBounds(290,500,100,30);
        btn3.setFocusable(false);
        btn3.setForeground(Color.cyan);
        btn3.setBackground(Color.blue);
        btn3.setFont(f2);
        btn3.setCursor(cursor);
        c.add(btn3);
        
        btn3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            
            JOptionPane.showMessageDialog(null,"Demo Made For Java Lab by Shifat,jahin and Shahadat","Credit",JOptionPane.INFORMATION_MESSAGE);
            
            
            
            }
        });
       
        
    
        
        
        
    }
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        BrickBreaking startframe = new BrickBreaking();
        startframe.setVisible(true);
        startframe.setSize(700,600);
        startframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.setLocationRelatedTo(null);
        startframe.setLocation(20,20);
        startframe.setTitle("BrickBreaking Demo");
        //startframe.setBounds(10,10,700,600);
        
        
    }
    
}
